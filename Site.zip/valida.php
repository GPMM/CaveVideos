<?php 

	include("conectaBanco.php");

	$user=$_REQUEST["user"];
	$senha=$_REQUEST["senha"];
	$confirmacao=0;

	$sql = mysql_query("select * from user where user = '$user'");
	
	if($sql){

		$row = mysql_fetch_assoc($sql);

		if($row['token'] == $senha){
			
			$confirmacao=1;

		}
		
	}

	session_start();		
	if($confirmacao)
	{
		$_SESSION["user"]=$user;
		header("location:index.php");
	}
	else
	{
		header("location:login.php");
		
	}
?>