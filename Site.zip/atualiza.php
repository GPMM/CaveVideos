<?php
	include("verifica.php");
	include("conectaBanco.php");

	$t = $_REQUEST['t'];

	if( $t == 'p' ){
		$id = $_REQUEST['id_position'];			
		$bank = "position";
		$tipoid = "id_position";
		$nome = $_REQUEST['pname'];
		$x = $_REQUEST['px'];
		$y = $_REQUEST['py'];
		$z = $_REQUEST['pz'];
	}
	if( $t == 'r' ){
		$id = $_REQUEST['id_rotation'];
		$bank = "rotation";
		$tipoid = "id_rotation";
		$nome = $_REQUEST['rname'];
		$x = $_REQUEST['rx'];
		$y = $_REQUEST['ry'];
		$z = $_REQUEST['rz'];
	}
	if( $t == 's' ){
		$id = $_REQUEST['id_size'];
		$bank = "size";
		$tipoid = "id_size";
		$nome = $_REQUEST['sname'];
		$x = $_REQUEST['sx'];
		$y = $_REQUEST['sy'];
		$z = $_REQUEST['sz'];
	}
	
	$sql = mysql_query("update $bank set nome = '$nome', x = '$x', y ='$y', z = '$z' where $tipoid = '$id'");
	
	if($sql){
		header("location:ver.php");
	}
	else{
		echo mysql_error();
	}
?>