<?php include("conectaBanco.php");
		include("verifica.php"); 
?>
<head>
		<title>Coordenadas</title>
</head>
	<div style='float:right'><a href='index.php'>Voltar</a></div>
<?php
		
		$sql1 = mysql_query("select * from position");
		echo"<h1>Position:</h1><br><br>";
		if($sql1){

			$linha1 = mysql_fetch_assoc($sql1);
			echo"<ul style='list-style:none'>";
			while($linha1){

				echo"<li style='display:inline'>
						<ul style='list-style:none'>
							<li>{$linha1['nome']}:</li>
							<li>X:{$linha1['x']}</li>
							<li>Y:{$linha1['y']}</li>
							<li>Z:{$linha1['z']}</li>
							<li><a href='exclui.php?id={$linha1['id_position']}'>Excluir</a> 
								<a href='edita.php?id={$linha1['id_position']}&t=p'>Editar</a></li>
						</ul>
						<br><hr style='width:50%' align='left'>
					</li>";
				$linha1 = mysql_fetch_assoc($sql1);

			}
			echo"</ul><hr>";
		}

		$sql1 = mysql_query("select * from rotation");
		echo"<h1>Rotation:</h1><br><br>";
		if($sql1){

			$linha1 = mysql_fetch_assoc($sql1);
			echo"<ul style='list-style:none'>";
			while($linha1){

				echo"<li style='display:inline'>
						<ul style='list-style:none'>
							<li>{$linha1['nome']}:</li>
							<li>X:{$linha1['x']}</li>
							<li>Y:{$linha1['y']}</li>
							<li>Z:{$linha1['z']}</li>
							<li><a href='exclui.php?id={$linha1['id_rotation']}'>Excluir</a> 
								<a href='edita.php?id={$linha1['id_rotation']}&t=r'>Editar</a></li>
						</ul>
						<br><hr style='width:50%' align='left'>
					</li>";
				$linha1 = mysql_fetch_assoc($sql1);

			}
			echo"</ul><hr>";
		}
		$sql1 = mysql_query("select * from size");
		echo"<h1>size:</h1><br><br>";
		if($sql1){

			$linha1 = mysql_fetch_assoc($sql1);
			echo"<ul style='list-style:none'>";
			while($linha1){

				echo"<li style='display:inline'>
						<ul style='list-style:none'>
							<li>{$linha1['nome']}:</li>
							<li>X:{$linha1['x']}</li>
							<li>Y:{$linha1['y']}</li>
							<li>Z:{$linha1['z']}</li>
							<li><a href='exclui.php?id={$linha1['id_size']}'>Excluir</a> 
								<a href='edita.php?id={$linha1['id_size']}&t=s'>Editar</a></li>
						</ul>
						<br><hr style='width:50%' align='left'>
					</li>";
				$linha1 = mysql_fetch_assoc($sql1);

			}
			echo"</ul><hr>";
		}
		mysql_close($link);
	?>