<form action='valida.php' method='post'>
	<input type='text' name='user' placeholder='User'>
	<input type='password' name='senha' placeholder='Password'>
	<input type='submit' value='Send'>
</form>