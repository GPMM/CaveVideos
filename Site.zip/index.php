<?php include("verifica.php"); ?>
<html>
	<head>
		<title>Inicio</title>
	</head>
	<body>
		<center>
			<h1>Adicionar:</h1>
			<form action="setNumbers.php">
				<b>Nome:</b><br><input required='' type="text" name="pname"><br><br>
				Position:<br>
				<b>X:</b><br><input required='' value='0' type="number" name="px"><br>
				<b>Y:</b><br><input required='' value='0' type="number" name="py"><br>
				<b>Z:</b><br><input required='' value='0' type="number" name="pz"><br>
				<br>
				Rotation:<br>
				<b>X:</b><br><input required='' value='0' type="number" name="rx"><br>
				<b>Y:</b><br><input required='' value='0' type="number" name="ry"><br>
				<b>Z:</b><br><input required='' value='0' type="number" name="rz"><br>
				<br>
				Size:<br>
				<b>X:</b><br><input required='' value='0' type="number" name="sx"><br>
				<b>Y:</b><br><input required='' value='0' type="number" name="sy"><br>
				<b>Z:</b><br><input required='' value='0' type="number" name="sz"><br>
				<input type="submit" name="Enviar">
			</form><br><br>
			<?php
				include("fileUploader.php");
			?>
			<br><hr>
			<a href='ver.php'>Vizualizar Dados</a><br>
			<a href='sair.php'>Sair</a>
		</center>
	</body>
</html>