<?php
	
	include("conectaBanco.php");

	$nome = $_REQUEST['nome'];

	$sql1 = mysql_query("select * from position where nome = '$nome'");
	$sql2 = mysql_query("select * from rotation where nome = '$nome'");
	$sql3 = mysql_query("select * from size where nome = '$nome'");

	if($sql1 && $sql2 && $sql3){
		
		$row1 = mysql_fetch_assoc($sql1);
		$row2 = mysql_fetch_assoc($sql2);
		$row3 = mysql_fetch_assoc($sql3);

		if( $row1 && $row2 ){

			$px = $row1['x'];
			$py = $row1['y'];
			$pz = $row1['z'];

			$rx = $row2['x'];
			$ry = $row2['y'];
			$rz = $row2['z'];

			$sx = $row3['x'];
			$sy = $row3['y'];
			$sz = $row3['z'];			

		}
		else{

			$px = 0;
			$py = 0;
			$pz = 0;

			$rx = 0;
			$ry = 0;
			$rz = 0;

			$sx = 1;
			$sy = 1;
			$sz = 1;			

		}
	
	}
	else{
			
			$px = 0;
			$py = 0;
			$pz = 0;

			$rx = 0;
			$ry = 0;
			$rz = 0;

			$sx = 1;
			$sy = 1;
			$sz = 1;
	}

	echo"$px;$py;$pz|$rx;$ry;$rz|$sx;$sy;$sz";

?>