<?php
	
	if(isset($_POST['submit'])){

		$nome = $_REQUEST['nomeArquivo'];

		$file = $_FILES['file'];

		$fileName = $_FILES['file']['name'];
		$fileTmp = $_FILES['file']['tmp_name'];
		$fileSize = $_FILES['file']['size'];
		$fileError = $_FILES['file']['error'];
		$fileType = $_FILES['file']['type'];	

		$fileExt = explode('.',$fileName);
		$fileActualExt = strtolower(end($fileExt));

		$allowed = array('mp4');

		if(in_array($fileActualExt, $allowed)){

			if($fileError === 0){

				$fileNameNew = $nome.".".$fileActualExt;
				$fileDestination = "videos/".$fileNameNew;
				move_uploaded_file($fileTmp, $fileDestination);
				header("location:index.php?uploadSucess	");

			}
			else{

				echo"Erro ao fazer upload do arquivo!";

			}

		}
		else{

			echo"Tipo não permitido!";

		}

	}
	else{

		header("location: index.php?errorNotSubmit");

	}



?>