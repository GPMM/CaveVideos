<?php
	include("verifica.php");
	include("conectaBanco.php");
	
	$id = $_REQUEST['id'];

	$sql1 = mysql_query("delete from position where id_position = '$id'");
	$sql2 = mysql_query("delete from rotation where id_rotation = '$id'");
	$sql2 = mysql_query("delete from size where id_size = '$id'");

	if($sql1 && $sql2){
		header("location:ver.php");
	}
	else{
		echo mysql_error();
	}
	
?>