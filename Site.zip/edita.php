<?php include("verifica.php");
	include("conectaBanco.php");
?>
<head>
		<title>Edita</title>
</head>
	<div style='float:right'><a href='index.php'>Voltar</a></div>
<?php

	$id = $_REQUEST['id'];
	$t = $_REQUEST['t'];

	if( $t == 'p'){
		$sql = mysql_query("select * from position where id_position = '$id'");
	}
	else{
		if( $t == 'r' ){
			$sql = mysql_query("select * from rotation where id_rotation = '$id'");
		}
		else{

			if( $t == 's' ){
				$sql = mysql_query("select * from size where id_size = '$id'");
			}
			else{

				echo "T = $t";

			}

		}

	}

	if($sql){

		$linha1 = mysql_fetch_assoc($sql);

		if(!$linha1){
			echo mysql_error();
		}
		else{

			if($t == 'p'){
				echo"<h1>Position:</h1>";
				echo"
				<form action='atualiza.php'>
					<input type='hidden' value='{$linha1['id_position']}' name='id_position'/>
					<input type='hidden' value='p' name='t'/>
					<b>Nome:</b><br><input value='{$linha1['nome']}' type='text' name='pname'><br>
					<b>X:</b><br><input value='{$linha1['x']}' required='' value='0' type='number' name='px'><br>
					<b>Y:</b><br><input value='{$linha1['y']}' required='' value='0' type='number' name='py'><br>
					<b>Z:</b><br><input value='{$linha1['z']}' required='' value='0' type='number' name='pz'><br>
					<br>
					<input type='submit' name='Enviar'>
				</form>
				";
			}
			if($t == 'r'){
				echo"<h1>Rotation:</h1>";
				echo"
				<form action='atualiza.php'>
					<input type='hidden' value='{$linha1['id_rotation']}' name='id_rotation'/>
					<input type='hidden' value='r' name='t'/>
					<b>Nome:</b><br><input value='{$linha1['nome']}' type='text' name='rname'><br>
					<b>X:</b><br><input value='{$linha1['x']}' required='' value='0' type='number' name='rx'><br>
					<b>Y:</b><br><input value='{$linha1['y']}' required='' value='0' type='number' name='ry'><br>
					<b>Z:</b><br><input value='{$linha1['z']}' required='' value='0' type='number' name='rz'><br>
					<br>
					<input type='submit' name='Enviar'>
				</form>
				";
			}
			if($t == 's'){
				echo"<h1>Size:</h1>";
				echo"
				<form action='atualiza.php'>
					<input type='hidden' value='{$linha1['id_size']}' name='id_size'/>
					<input type='hidden' value='s' name='t'/>
					<b>Nome:</b><br><input value='{$linha1['nome']}' type='text' name='sname'><br>
					<b>X:</b><br><input value='{$linha1['x']}' required='' value='0' type='number' name='sx'><br>
					<b>Y:</b><br><input value='{$linha1['y']}' required='' value='0' type='number' name='sy'><br>
					<b>Z:</b><br><input value='{$linha1['z']}' required='' value='0' type='number' name='sz'><br>
					<br>
					<input type='submit' name='Enviar'>
				</form>
				";
			}
		}

	}
	else{

		echo mysql_error();

	}
	
	
?>