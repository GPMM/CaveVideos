<?php
	include("verifica.php");
	include("conectaBanco.php");
	
	$name = $_REQUEST['name'];

	$px = $_REQUEST['px'];
	$py = $_REQUEST['py'];
	$pz = $_REQUEST['pz'];

	$rx = $_REQUEST['rx'];
	$ry = $_REQUEST['ry'];
	$rz = $_REQUEST['rz'];

	$sql1 = mysql_query("insert into position (x,y,z,nome) values ('$px','$py','$pz','$name')");

	$sql2 = mysql_query("insert into rotation (x,y,z,nome) values ('$rx','$ry','$rz','$name')");

	$sql2 = mysql_query("insert into size (x,y,z,nome) values ('$sx','$sy','$sz','$name')");

	if($sql1 && $sql2){
		header("location:index.php");
	}
	else{
		echo mysql_error();
	}
?>