<hr>
<h1>Vídeo:</h1>
<form action='upload.php' method='POST' enctype='multipart/form-data'>
	<strong>Nome</strong><br><input type="text" name="nomeArquivo" required='' placeholder="Nome sem o formato"><br><br>
	<strong>(Arquivo MP4)</strong><br><input type='file' name='file'><br><br>
	<button type='submit' name='submit'>Enviar</button>
</form>