﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class dataLoader : MonoBehaviour {

	public string nome = "";
	private string [] prs;
	private string [] p;
	private string [] r; 
	private string [] s; 

	// Use this for initialization
	IEnumerator Start () {
		WWW itemsData = new WWW("http://icjoel.000webhostapp.com/pattern.php?nome="+nome);
		yield return itemsData;
		string textoPag = itemsData.text;
		Debug.Log(textoPag);
		prs = textoPag.Split('|');
		p = prs[0].Split(';');
		r = prs[1].Split(';');
		s = prs[2].Split(';');
		transform.localPosition = new Vector3(float.Parse(p[0]),float.Parse(p[1]),float.Parse(p[2]));
		transform.localRotation = Quaternion.Euler(float.Parse(r[0]),float.Parse(r[1]),float.Parse(r[2]));
		transform.localScale = new Vector3(float.Parse(s[0]),float.Parse(s[1]),float.Parse(s[2]));
	}
	
	// Update is called once per frame
	/*void Update () {
	
	}*/
}
